

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class Final
 */
@WebServlet("/Final")
public class Final extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Final() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub 
		int senderamt=0;
		HttpSession ses=request.getSession();
		
		String s=(String) ses.getAttribute("sendername");
	
		PrintWriter pr=response.getWriter();
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/ACP", "root", "sneha");
			String s1="select *from members where name=?";
			
			PreparedStatement ps=(PreparedStatement) con.prepareStatement(s1);
			ps.setString(1, s);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				senderamt=rs.getInt(3);
						
			}
			
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
		}
		
		ses=request.getSession();
		ses.invalidate();
		
		pr.print("<html><body background=\"image/logout.jpg\"><h1>");
		pr.println("Thank you ");
		s=s.toUpperCase();
		pr.print(s+" :) <br> Your remaining balance is Rs."+senderamt+"<br>");
		
		
		
		pr.print("<a href=\"http://localhost:8081/Book-a-Ticket/demo.html\">LOGOUT</a>" );

		
		pr.print("</h1></body></html>");
		pr.close();
		
	}

}
