import java.sql.Connection;
import java.sql.DriverManager;


import java.sql.ResultSet;

import com.mysql.jdbc.PreparedStatement;


public class login {

	public static boolean validate(String name, String pass) {
		boolean status=false;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/ACP", "root", "sneha");
			
			PreparedStatement pstmt=(PreparedStatement) con.prepareStatement("select * from logi where name=? and password=?");
			
			pstmt.setString(1, name);
			pstmt.setString(2, pass);
			
			ResultSet rs=pstmt.executeQuery();
			status=rs.next();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return status;
		
	}
}
