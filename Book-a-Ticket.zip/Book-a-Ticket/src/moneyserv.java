

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class moneyserv
 */
@WebServlet("/moneyserv")
public class moneyserv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public moneyserv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String acno=request.getParameter("accno");
		String rname=request.getParameter("rname");
		String money=request.getParameter("money");
		
		HttpSession session=request.getSession();
		String sname = (String)session.getAttribute("sendername");
		
		
		int mon = Integer.parseInt(money);
		
		if(acno.equals("") || sname.equals("") ||rname.equals("") || money.equals(""))
		{
			System.out.println("please enter all fields!");
			PrintWriter out=response.getWriter();
			out.println("please enter all fields!");
			RequestDispatcher rd=request.getRequestDispatcher("money.html");
			rd.forward(request, response);
			
		}
		else
		{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/ACP", "root","sneha");
						
			String str="select * from members where name=?";
			PreparedStatement pr=(PreparedStatement) con.prepareStatement(str);
			pr.setString(1, sname);
			ResultSet rs = pr.executeQuery();
			int sbal=0 ;
			while(rs.next())
			{
				sbal = rs.getInt(3);
			}

			
			String str6="select * from members where name=?";
			PreparedStatement pr6=(PreparedStatement) con.prepareStatement(str6);
			pr6.setString(1, rname);
			ResultSet rs6 = pr6.executeQuery();
			int rbal=0 ;
			while(rs6.next())
			{
				rbal = rs6.getInt(3);
			}

			String str1="update members set balance=? where name=?";
			PreparedStatement pr1=(PreparedStatement) con.prepareStatement(str1);
			pr1.setInt(1, (sbal-mon));
			pr1.setString(2, sname);
			int result=pr1.executeUpdate();


						
			String str2="update members set balance=? where name=?";
			PreparedStatement pr2=(PreparedStatement) con.prepareStatement(str2);
			pr2.setInt(1, (rbal+mon));
			pr2.setString(2, rname);
			int result1=pr2.executeUpdate();

			
			if(result!=0 && result1!=0)
			{
				PrintWriter out=response.getWriter();
				out.print("Balance :"+(sbal-mon));
				RequestDispatcher rd=request.getRequestDispatcher("Final");
				rd.forward(request, response);
			}
			else
			{
				PrintWriter out=response.getWriter();
				out.print("error during transaction");
				RequestDispatcher rd=request.getRequestDispatcher("money.html");
				rd.include(request, response);
			}
				
		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		}

		
		
	}

}
