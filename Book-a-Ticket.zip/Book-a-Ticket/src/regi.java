

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.PreparedStatement;

/**
 * Servlet implementation class regi
 */
@WebServlet("/regi")
public class regi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public regi() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String un=request.getParameter("name");
		String pas=request.getParameter("pass");
		
		if(un.equals("") || pas.equals("") )
		{
			out.println("please enter all fields!");
			out.print("\n\n\n");
			RequestDispatcher rd=request.getRequestDispatcher("Regristration.html");
			rd.include(request, response);
			
			
		}
		else
		{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/ACP", "root","sneha");
			String str="insert into logi values (?,?)";
			String str1="insert into members values (?,NULL,1000)";
			
			PreparedStatement pr=(PreparedStatement) con.prepareStatement(str);
			pr.setString(1, un);
			pr.setString(2, pas);
			int result=pr.executeUpdate();
			
			
			PreparedStatement pr1=(PreparedStatement) con.prepareStatement(str1);
			pr1.setString(1, un);
			int result1=pr1.executeUpdate();
				
			if(result!=0 && result1!=0)
			{
				RequestDispatcher rd=request.getRequestDispatcher("demo.html");
				rd.forward(request, response);
			}
				else
				System.out.println("error");

		} catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
		}
	}
		
	

}
